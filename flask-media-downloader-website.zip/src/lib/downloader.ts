import { execSync, spawn, ChildProcess } from "child_process";
import path from "path";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";
import type { VideoInfo, SearchResult, DownloadProgress, DownloadRequest } from "./types";

const DOWNLOADS_DIR = path.join(process.cwd(), "downloads");
const TEMP_DIR = path.join(process.cwd(), "tmp");

// Ensure directories exist
function ensureDirs() {
  [DOWNLOADS_DIR, TEMP_DIR].forEach((dir) => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  });
}

ensureDirs();

// Active downloads tracking
const activeDownloads = new Map<string, DownloadProgress>();

export function getActiveDownloads(): DownloadProgress[] {
  return Array.from(activeDownloads.values());
}

export function getDownloadProgress(id: string): DownloadProgress | undefined {
  return activeDownloads.get(id);
}

export function clearCompletedDownloads(): void {
  for (const [id, dl] of activeDownloads) {
    if (dl.status === "completed" || dl.status === "failed") {
      activeDownloads.delete(id);
    }
  }
}

function parseFilesizeToStr(bytes: number): string {
  if (!bytes || bytes <= 0) return "Unknown";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function parseDuration(seconds: number): string {
  if (!seconds || seconds <= 0) return "Unknown";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export async function searchVideos(query: string, limit = 20): Promise<SearchResult[]> {
  try {
    const ytDlpPath = "yt-dlp";
    const args = [
      `ytsearch${limit}:${query}`,
      "--flat-playlist",
      "--dump-json",
      "--no-warnings",
      "--no-check-certificates",
      "--socket-timeout", "15",
    ];

    const output = execSync(`"${ytDlpPath}" ${args.map(a => `"${a}"`).join(" ")}`, {
      encoding: "utf-8",
      timeout: 30000,
      maxBuffer: 10 * 1024 * 1024,
    });

    const lines = output.trim().split("\n").filter(Boolean);
    const results: SearchResult[] = [];

    for (const line of lines) {
      try {
        const data = JSON.parse(line);
        results.push({
          id: data.id || data.webpage_url?.split("v=")?.[1] || uuidv4(),
          title: data.title || "Unknown Title",
          url: data.webpage_url || data.url || `https://youtube.com/watch?v=${data.id}`,
          thumbnail: data.thumbnail || data.thumbnails?.[0]?.url || "",
          duration: data.duration ? parseDuration(data.duration) : "Unknown",
          uploader: data.uploader || data.channel || "Unknown",
          viewCount: data.view_count || 0,
        });
      } catch {
        // Skip malformed JSON lines
      }
    }

    return results;
  } catch (error) {
    console.error("Search error:", error);
    return [];
  }
}

export async function getVideoInfo(url: string): Promise<VideoInfo | null> {
  try {
    const ytDlpPath = "yt-dlp";
    const args = [
      url,
      "--dump-json",
      "--no-warnings",
      "--no-check-certificates",
      "--socket-timeout", "15",
    ];

    const output = execSync(`"${ytDlpPath}" ${args.map(a => `"${a}"`).join(" ")}`, {
      encoding: "utf-8",
      timeout: 30000,
      maxBuffer: 10 * 1024 * 1024,
    });

    const data = JSON.parse(output.trim());
    return {
      id: data.id || uuidv4(),
      title: data.title || "Unknown Title",
      url: data.webpage_url || url,
      thumbnail: data.thumbnail || data.thumbnails?.[0]?.url || "",
      duration: data.duration || 0,
      durationStr: parseDuration(data.duration || 0),
      uploader: data.uploader || data.channel || "Unknown",
      viewCount: data.view_count || 0,
      format: data.ext || "unknown",
      filesize: data.filesize || data.filesize_approx || 0,
      filesizeStr: parseFilesizeToStr(data.filesize || data.filesize_approx || 0),
    };
  } catch (error) {
    console.error("Info error:", error);
    return null;
  }
}

export async function startDownload(req: DownloadRequest): Promise<{ id: string; progress: DownloadProgress }> {
  const id = uuidv4();
  const progress: DownloadProgress = {
    id,
    title: "Fetching info...",
    status: "queued",
    progress: 0,
    speed: "",
    eta: "",
    format: req.format,
    startedAt: new Date().toISOString(),
  };

  activeDownloads.set(id, progress);

  // Start download in background
  processDownload(id, req).catch((error) => {
    const dl = activeDownloads.get(id);
    if (dl) {
      dl.status = "failed";
      dl.error = String(error);
    }
  });

  return { id, progress };
}

async function processDownload(id: string, req: DownloadRequest): Promise<void> {
  const dl = activeDownloads.get(id);
  if (!dl) return;

  try {
    // First get video info
    dl.status = "downloading";
    dl.progress = 5;

    const info = await getVideoInfo(req.url);
    if (info) {
      dl.title = info.title;
    }

    const ytDlpPath = "yt-dlp";
    const outputTemplate = path.join(DOWNLOADS_DIR, "%(title)s-%(id)s.%(ext)s");
    const tempOutput = path.join(TEMP_DIR, `${id}`);

    const args: string[] = [
      req.url,
      "--no-warnings",
      "--no-check-certificates",
      "--socket-timeout", "30",
      "--retries", "3",
      "--fragment-retries", "3",
      "--no-mtime",
    ];

    if (req.format === "mp3") {
      // Extract audio and convert to MP3 at 192kbps
      args.push(
        "--extract-audio",
        "--audio-format", "mp3",
        "--audio-quality", "192K",
        "-o", `${tempOutput}.%(ext)s`,
      );
    } else if (req.format === "mp4") {
      // Download best MP4 (video+audio merged)
      args.push(
        "-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "--merge-output-format", "mp4",
        "-o", `${tempOutput}.%(ext)s`,
      );
    } else {
      // Best quality
      args.push(
        "-f", "best",
        "-o", `${tempOutput}.%(ext)s`,
      );
    }

    dl.status = "downloading";

    await new Promise<void>((resolve, reject) => {
      const proc = spawn(ytDlpPath, args, {
        stdio: ["ignore", "pipe", "pipe"],
        env: { ...process.env, PYTHONUNBUFFERED: "1" },
      });

      let stderr = "";

      proc.stderr?.on("data", (data: Buffer) => {
        const text = data.toString();
        stderr += text;

        // Parse progress: [download]  45.2% of ~50MB at 2.1MB/s ETA 00:12
        const progressMatch = text.match(/(\d+\.?\d*)%/);
        if (progressMatch) {
          dl.progress = Math.min(parseFloat(progressMatch[1]), 99);
        }

        const speedMatch = text.match(/at\s+([\d.]+\s*\w+\/s)/);
        if (speedMatch) {
          dl.speed = speedMatch[1];
        }

        const etaMatch = text.match(/ETA\s+(\d+:\d+)/);
        if (etaMatch) {
          dl.eta = etaMatch[1];
        }
      });

      proc.on("close", (code) => {
        if (code === 0) {
          resolve();
        } else {
          reject(new Error(`yt-dlp exited with code ${code}: ${stderr.slice(-500)}`));
        }
      });

      proc.on("error", reject);
    });

    // Find the output file in temp directory
    dl.status = req.format === "mp3" ? "converting" : "merging";
    dl.progress = 95;

    const tempFiles = fs.readdirSync(TEMP_DIR).filter((f) => f.startsWith(id));
    
    if (tempFiles.length === 0) {
      // Check downloads directory too
      const allFiles = fs.readdirSync(DOWNLOADS_DIR);
      const matchingFiles = allFiles.filter((f) => {
        return f.includes(id);
      });

      if (matchingFiles.length > 0) {
        dl.outputFile = matchingFiles[0];
        dl.outputPath = `/api/files/${encodeURIComponent(matchingFiles[0])}`;
      }
    } else {
      // Move from temp to downloads
      const srcFile = path.join(TEMP_DIR, tempFiles[0]);
      const ext = path.extname(tempFiles[0]);
      const safeTitle = dl.title
        .replace(/[^a-zA-Z0-9]/g, "_")
        .substring(0, 60);
      const destName = `${safeTitle}-${id}${ext}`;
      const destFile = path.join(DOWNLOADS_DIR, destName);

      fs.copyFileSync(srcFile, destFile);
      // Clean up temp
      try { fs.unlinkSync(srcFile); } catch {}

      dl.outputFile = destName;
      dl.outputPath = `/api/files/${encodeURIComponent(destName)}`;
    }

    dl.status = "completed";
    dl.progress = 100;

  } catch (error) {
    console.error(`Download ${id} failed:`, error);
    dl.status = "failed";
    dl.error = String(error);
  }
}

export function getDownloadedFiles(): { name: string; size: number; sizeStr: string; created: string }[] {
  ensureDirs();
  try {
    return fs.readdirSync(DOWNLOADS_DIR)
      .filter((f) => f !== ".gitkeep")
      .map((name) => {
        const stats = fs.statSync(path.join(DOWNLOADS_DIR, name));
        return {
          name,
          size: stats.size,
          sizeStr: parseFilesizeToStr(stats.size),
          created: stats.birthtime.toISOString(),
        };
      })
      .sort((a, b) => new Date(b.created).getTime() - new Date(a.created).getTime());
  } catch {
    return [];
  }
}

export function getFilePath(filename: string): string | null {
  const safeName = path.basename(filename);
  const filePath = path.join(DOWNLOADS_DIR, safeName);
  if (fs.existsSync(filePath)) {
    return filePath;
  }
  return null;
}

export function deleteFile(filename: string): boolean {
  const filePath = getFilePath(filename);
  if (filePath) {
    fs.unlinkSync(filePath);
    return true;
  }
  return false;
}

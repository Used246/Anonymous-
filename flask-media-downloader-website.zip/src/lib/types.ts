export interface VideoInfo {
  id: string;
  title: string;
  url: string;
  thumbnail: string;
  duration: number;
  durationStr: string;
  uploader: string;
  viewCount: number;
  format: string;
  filesize: number;
  filesizeStr: string;
}

export interface SearchResult {
  id: string;
  title: string;
  url: string;
  thumbnail: string;
  duration: string;
  uploader: string;
  viewCount: number;
}

export interface DownloadProgress {
  id: string;
  title: string;
  status: "queued" | "downloading" | "converting" | "merging" | "completed" | "failed";
  progress: number;
  speed: string;
  eta: string;
  outputFile?: string;
  outputPath?: string;
  format: "mp4" | "mp3" | "best";
  error?: string;
  startedAt: string;
}

export interface DownloadRequest {
  url: string;
  format: "mp4" | "mp3" | "best";
  quality?: string;
}

export interface SearchRequest {
  query: string;
  limit?: number;
}

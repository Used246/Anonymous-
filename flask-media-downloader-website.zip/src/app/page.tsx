"use client";

import { useState, useEffect, useCallback, useRef } from "react";

interface SearchResult {
  id: string;
  title: string;
  url: string;
  thumbnail: string;
  duration: string;
  uploader: string;
  viewCount: number;
}

interface VideoInfo {
  id: string;
  title: string;
  url: string;
  thumbnail: string;
  duration: number;
  durationStr: string;
  uploader: string;
  viewCount: number;
  format: string;
  filesize: number;
  filesizeStr: string;
}

interface DownloadProgress {
  id: string;
  title: string;
  status: "queued" | "downloading" | "converting" | "merging" | "completed" | "failed";
  progress: number;
  speed: string;
  eta: string;
  outputFile?: string;
  outputPath?: string;
  format: "mp4" | "mp3" | "best";
  error?: string;
  startedAt: string;
}

interface DownloadedFile {
  name: string;
  size: number;
  sizeStr: string;
  created: string;
}

type Tab = "search" | "url" | "downloads";

function formatViews(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<Tab>("url");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [directUrl, setDirectUrl] = useState("");
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [fetchingInfo, setFetchingInfo] = useState(false);
  const [downloadFormat, setDownloadFormat] = useState<"mp4" | "mp3" | "best">("best");
  const [downloads, setDownloads] = useState<DownloadProgress[]>([]);
  const [downloadedFiles, setDownloadedFiles] = useState<DownloadedFile[]>([]);
  const [loadingDownloads, setLoadingDownloads] = useState(false);
  const [error, setError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Clear messages
  const clearMessages = () => { setError(""); setSuccessMsg(""); };

  // Load downloaded files
  const loadDownloadedFiles = useCallback(async () => {
    try {
      const res = await fetch("/api/downloads");
      const data = await res.json();
      if (data.files) setDownloadedFiles(data.files);
    } catch {}
  }, []);

  useEffect(() => { loadDownloadedFiles(); }, [loadDownloadedFiles]);

  // Search
  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    clearMessages();
    setSearching(true);
    setSearchResults([]);
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(searchQuery.trim())}&limit=20`);
      const data = await res.json();
      if (data.error) { setError(data.error); } else { setSearchResults(data.results || []); }
    } catch {
      setError("Search failed. Check your connection.");
    } finally {
      setSearching(false);
    }
  };

  // Fetch video info from URL
  const handleFetchInfo = async () => {
    if (!directUrl.trim()) return;
    clearMessages();
    setFetchingInfo(true);
    setVideoInfo(null);
    try {
      const res = await fetch(`/api/info?url=${encodeURIComponent(directUrl.trim())}`);
      const data = await res.json();
      if (data.error) { setError(data.error); } else { setVideoInfo(data.info); }
    } catch {
      setError("Failed to fetch video info.");
    } finally {
      setFetchingInfo(false);
    }
  };

  // Start download
  const startDownload = async (url: string, format: "mp4" | "mp3" | "best") => {
    clearMessages();
    try {
      const res = await fetch("/api/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, format }),
      });
      const data = await res.json();
      if (data.error) {
        setError(data.error);
        return;
      }
      if (data.id) {
        setDownloads((prev) => [data.progress, ...prev]);
        setSuccessMsg(`Download started: ${data.progress.title}`);
        pollDownload(data.id);
      }
    } catch {
      setError("Failed to start download.");
    }
  };

  // Poll download progress
  const pollDownload = (id: string) => {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/download?id=${id}`);
        const data = await res.json();
        if (data.progress) {
          setDownloads((prev) =>
            prev.map((d) => (d.id === id ? data.progress : d))
          );
          if (data.progress.status === "completed" || data.progress.status === "failed") {
            if (pollRef.current) clearInterval(pollRef.current);
            loadDownloadedFiles();
            if (data.progress.status === "completed") {
              setSuccessMsg(`✓ Downloaded: ${data.progress.title}`);
            }
          }
        }
      } catch {}
    }, 1000);
  };

  useEffect(() => {
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, []);

  // Delete downloaded file
  const handleDeleteFile = async (filename: string) => {
    try {
      await fetch(`/api/downloads?file=${encodeURIComponent(filename)}`, { method: "DELETE" });
      loadDownloadedFiles();
      setSuccessMsg("File deleted.");
    } catch {
      setError("Failed to delete file.");
    }
  };

  const activeDownloads = downloads.filter(
    (d) => d.status !== "completed" && d.status !== "failed"
  );

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-anon-border glass sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-anon-accent to-emerald-600 flex items-center justify-center text-anon-black font-bold text-lg animate-glow">
              A
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white">Anonymous</h1>
              <p className="text-xs text-anon-muted">Tech Team 2026</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2">
            <span className="tag">v2.0</span>
            <span className="tag">192kbps MP3</span>
            <span className="tag">MP4 Merge</span>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-anon-border py-12">
        <div className="absolute inset-0 bg-gradient-to-b from-anon-accent/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-5xl mx-auto px-4 text-center relative z-10">
          <h2 className="text-4xl sm:text-5xl font-extrabold tracking-tight mb-3">
            <span className="text-white">Download from </span>
            <span className="bg-gradient-to-r from-anon-accent to-emerald-400 bg-clip-text text-transparent">
              YouTube & Social Media
            </span>
          </h2>
          <p className="text-anon-muted text-lg max-w-2xl mx-auto">
            Extract MP3 at 192kbps · Merge MP4 videos · Lightning fast · 100% Anonymous
          </p>
        </div>
      </section>

      {/* Main Content */}
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-8">
        {/* Messages */}
        {error && (
          <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 flex items-center justify-between animate-fade-in">
            <span>⚠ {error}</span>
            <button onClick={clearMessages} className="text-red-400 hover:text-red-300 ml-4">✕</button>
          </div>
        )}
        {successMsg && (
          <div className="mb-6 p-4 rounded-xl bg-anon-accent/10 border border-anon-accent/30 text-anon-accent flex items-center justify-between animate-fade-in">
            <span>{successMsg}</span>
            <button onClick={clearMessages} className="text-anon-accent hover:text-white ml-4">✕</button>
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 mb-8 bg-anon-dark rounded-2xl p-1.5 border border-anon-border">
          {([
            ["search", "🔍 Keyword Search"],
            ["url", "🔗 Direct URL"],
            ["downloads", "📥 Downloads"],
          ] as [Tab, string][]).map(([tab, label]) => (
            <button
              key={tab}
              onClick={() => { setActiveTab(tab); clearMessages(); }}
              className={`flex-1 py-3 px-4 rounded-xl text-sm font-semibold transition-all duration-200 ${
                activeTab === tab
                  ? "bg-anon-accent text-anon-black shadow-lg shadow-anon-accent/20"
                  : "text-anon-muted hover:text-white"
              }`}
            >
              {label}
              {tab === "downloads" && activeDownloads.length > 0 && (
                <span className="ml-2 inline-flex items-center justify-center w-5 h-5 rounded-full bg-anon-warning text-black text-xs font-bold">
                  {activeDownloads.length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab: Keyword Search */}
        {activeTab === "search" && (
          <div className="animate-slide-up space-y-6">
            <div className="glass-card p-6">
              <h3 className="text-lg font-semibold mb-4">Search YouTube Videos</h3>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder="Search by keywords, artist, title..."
                  className="input-field flex-1"
                />
                <button
                  onClick={handleSearch}
                  disabled={searching || !searchQuery.trim()}
                  className="btn-primary whitespace-nowrap"
                >
                  {searching ? "Searching..." : "🔍 Search"}
                </button>
              </div>
            </div>

            {searching && (
              <div className="flex items-center justify-center py-12">
                <div className="w-8 h-8 border-2 border-anon-accent border-t-transparent rounded-full animate-spin-slow" />
                <span className="ml-3 text-anon-muted">Searching...</span>
              </div>
            )}

            {searchResults.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {searchResults.map((result) => (
                  <div key={result.id} className="glass-card p-4 flex gap-4 group">
                    {result.thumbnail && (
                      <img
                        src={result.thumbnail}
                        alt={result.title}
                        className="w-32 h-18 rounded-lg object-cover bg-anon-dark"
                        loading="lazy"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm line-clamp-2 group-hover:text-anon-accent transition-colors">
                        {result.title}
                      </h4>
                      <p className="text-xs text-anon-muted mt-1">{result.uploader}</p>
                      <div className="flex items-center gap-3 mt-2">
                        <span className="text-xs text-anon-muted">{result.duration}</span>
                        <span className="text-xs text-anon-muted">{formatViews(result.viewCount)} views</span>
                      </div>
                      <div className="flex gap-2 mt-3">
                        <button
                          onClick={() => startDownload(result.url, "best")}
                          className="text-xs px-3 py-1.5 rounded-lg bg-anon-accent/15 text-anon-accent hover:bg-anon-accent/25 transition-colors"
                        >
                          ↓ Best
                        </button>
                        <button
                          onClick={() => startDownload(result.url, "mp3")}
                          className="text-xs px-3 py-1.5 rounded-lg bg-anon-accent2/15 text-purple-400 hover:bg-anon-accent2/25 transition-colors"
                        >
                          🎵 MP3 192k
                        </button>
                        <button
                          onClick={() => startDownload(result.url, "mp4")}
                          className="text-xs px-3 py-1.5 rounded-lg bg-blue-500/15 text-blue-400 hover:bg-blue-500/25 transition-colors"
                        >
                          🎬 MP4
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {!searching && searchResults.length === 0 && searchQuery && (
              <p className="text-center text-anon-muted py-12">No results found. Try different keywords.</p>
            )}
          </div>
        )}

        {/* Tab: Direct URL */}
        {activeTab === "url" && (
          <div className="animate-slide-up space-y-6">
            <div className="glass-card p-6">
              <h3 className="text-lg font-semibold mb-4">Paste Video URL</h3>
              <p className="text-sm text-anon-muted mb-4">
                Supports YouTube, TikTok, Instagram, Twitter/X, Facebook, Vimeo, SoundCloud, and more.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  value={directUrl}
                  onChange={(e) => setDirectUrl(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleFetchInfo()}
                  placeholder="https://www.youtube.com/watch?v=... or any social media URL"
                  className="input-field flex-1"
                />
                <button
                  onClick={handleFetchInfo}
                  disabled={fetchingInfo || !directUrl.trim()}
                  className="btn-primary whitespace-nowrap"
                >
                  {fetchingInfo ? "Fetching..." : "🔗 Analyze"}
                </button>
              </div>
            </div>

            {fetchingInfo && (
              <div className="flex items-center justify-center py-12">
                <div className="w-8 h-8 border-2 border-anon-accent border-t-transparent rounded-full animate-spin-slow" />
                <span className="ml-3 text-anon-muted">Fetching video info...</span>
              </div>
            )}

            {videoInfo && (
              <div className="glass-card p-6 animate-slide-up space-y-5">
                <div className="flex flex-col sm:flex-row gap-5">
                  {videoInfo.thumbnail && (
                    <img
                      src={videoInfo.thumbnail}
                      alt={videoInfo.title}
                      className="w-full sm:w-48 rounded-xl object-cover bg-anon-dark"
                    />
                  )}
                  <div className="flex-1">
                    <h4 className="text-lg font-semibold">{videoInfo.title}</h4>
                    <p className="text-sm text-anon-muted mt-1">{videoInfo.uploader}</p>
                    <div className="flex flex-wrap gap-3 mt-3">
                      <span className="tag">{videoInfo.durationStr}</span>
                      <span className="tag">{formatViews(videoInfo.viewCount)} views</span>
                      <span className="tag">{videoInfo.filesizeStr}</span>
                    </div>
                  </div>
                </div>

                <div className="border-t border-anon-border pt-5">
                  <h5 className="text-sm font-semibold mb-3">Choose Download Format:</h5>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {([
                      ["best", "⚡ Best Quality", "Auto-select best available format"],
                      ["mp4", "🎬 MP4 Video", "Video + audio merged into MP4"],
                      ["mp3", "🎵 MP3 192kbps", "Extract high-quality audio"],
                    ] as const).map(([fmt, title, desc]) => (
                      <button
                        key={fmt}
                        onClick={() => setDownloadFormat(fmt)}
                        className={`p-4 rounded-xl border-2 text-left transition-all ${
                          downloadFormat === fmt
                            ? "border-anon-accent bg-anon-accent/10"
                            : "border-anon-border hover:border-anon-muted"
                        }`}
                      >
                        <div className="font-semibold text-sm">{title}</div>
                        <div className="text-xs text-anon-muted mt-1">{desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => startDownload(videoInfo.url, downloadFormat)}
                  className="btn-primary w-full text-center text-lg py-4"
                >
                  ⬇ Download {downloadFormat.toUpperCase()}
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab: Downloads */}
        {activeTab === "downloads" && (
          <div className="animate-slide-up space-y-6">
            {/* Active Downloads */}
            {activeDownloads.length > 0 && (
              <div className="glass-card p-6">
                <h3 className="text-lg font-semibold mb-4">
                  Active Downloads ({activeDownloads.length})
                </h3>
                <div className="space-y-4">
                  {downloads.filter((d) => d.status !== "completed" && d.status !== "failed").map((dl) => (
                    <div key={dl.id} className="p-4 rounded-xl bg-anon-dark border border-anon-border">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm truncate flex-1">{dl.title}</span>
                        <span className={`tag ml-2 ${
                          dl.status === "downloading" ? "!bg-blue-500/15 !text-blue-400 !border-blue-500/30" :
                          dl.status === "converting" ? "!bg-yellow-500/15 !text-yellow-400 !border-yellow-500/30" :
                          dl.status === "merging" ? "!bg-purple-500/15 !text-purple-400 !border-purple-500/30" :
                          dl.status === "failed" ? "!bg-red-500/15 !text-red-400 !border-red-500/30" :
                          "!bg-anon-accent/15 !text-anon-accent !border-anon-accent/30"
                        }`}>
                          {dl.status}
                        </span>
                      </div>
                      <div className="progress-bar mb-2">
                        <div
                          className="progress-bar-fill"
                          style={{ width: `${dl.progress}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-anon-muted">
                        <span>{dl.progress.toFixed(1)}%</span>
                        <span>{dl.speed && `${dl.speed}`} {dl.eta && `· ETA ${dl.eta}`}</span>
                      </div>
                      {dl.error && (
                        <p className="text-xs text-red-400 mt-2 truncate">{dl.error}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Completed Downloads */}
            <div className="glass-card p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Completed Downloads</h3>
                <button
                  onClick={loadDownloadedFiles}
                  className="text-sm text-anon-accent hover:underline"
                >
                  🔄 Refresh
                </button>
              </div>

              {loadingDownloads && (
                <div className="flex items-center justify-center py-8">
                  <div className="w-6 h-6 border-2 border-anon-accent border-t-transparent rounded-full animate-spin-slow" />
                </div>
              )}

              {!loadingDownloads && downloadedFiles.length === 0 && (
                <div className="text-center py-12 text-anon-muted">
                  <div className="text-4xl mb-3">📭</div>
                  <p>No downloads yet. Search or paste a URL to get started!</p>
                </div>
              )}

              {downloadedFiles.length > 0 && (
                <div className="space-y-2">
                  {downloadedFiles.map((file) => (
                    <div
                      key={file.name}
                      className="flex items-center justify-between p-3 rounded-xl bg-anon-dark border border-anon-border hover:border-anon-accent/30 transition-colors group"
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <span className="text-xl">
                          {file.name.endsWith(".mp3") ? "🎵" : "🎬"}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium truncate">{file.name}</p>
                          <p className="text-xs text-anon-muted">{file.sizeStr}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-3">
                        <a
                          href={`/api/files/${encodeURIComponent(file.name)}`}
                          download
                          className="text-xs px-3 py-1.5 rounded-lg bg-anon-accent/15 text-anon-accent hover:bg-anon-accent/25 transition-colors whitespace-nowrap"
                        >
                          ⬇ Download
                        </a>
                        <button
                          onClick={() => handleDeleteFile(file.name)}
                          className="text-xs px-2 py-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors opacity-0 group-hover:opacity-100"
                        >
                          🗑
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Completed status downloads */}
            {downloads.filter((d) => d.status === "completed").map((dl) => (
              <div key={dl.id} className="glass-card p-4 flex items-center justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="text-xl">✅</span>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{dl.title}</p>
                    <p className="text-xs text-anon-muted">
                      {dl.format.toUpperCase()} · Completed
                    </p>
                  </div>
                </div>
                {dl.outputPath && (
                  <a
                    href={dl.outputPath}
                    download
                    className="btn-primary text-sm px-4 py-2"
                  >
                    ⬇ Save
                  </a>
                )}
              </div>
            ))}

            {/* Failed downloads */}
            {downloads.filter((d) => d.status === "failed").map((dl) => (
              <div key={dl.id} className="glass-card p-4 border-red-500/30">
                <div className="flex items-center gap-3">
                  <span className="text-xl">❌</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{dl.title}</p>
                    <p className="text-xs text-red-400 truncate">{dl.error || "Download failed"}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-anon-border mt-auto">
        <div className="max-w-5xl mx-auto px-4 py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-anon-accent/20 flex items-center justify-center text-xs text-anon-accent font-bold">
                A
              </div>
              <span className="text-sm text-anon-muted">
                Anonymous © 2026 — Anonymous Tech Team
              </span>
            </div>
            <div className="flex gap-4 text-xs text-anon-muted">
              <span>🔒 No logs stored</span>
              <span>⚡ yt-dlp powered</span>
              <span>🎵 MP3 192kbps</span>
              <span>🎬 MP4 merging</span>
            </div>
          </div>
          <p className="text-center text-xs text-anon-muted/50 mt-4">
            For personal use only. Respect copyright and platform terms of service.
          </p>
        </div>
      </footer>
    </div>
  );
}

import { NextRequest } from "next/server";
import { startDownload, getDownloadProgress, getActiveDownloads } from "@/lib/downloader";
import type { DownloadRequest } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body: DownloadRequest = await req.json();
    
    if (!body.url || body.url.trim().length === 0) {
      return Response.json({ error: "URL is required" }, { status: 400 });
    }

    const format = ["mp4", "mp3", "best"].includes(body.format) ? body.format : "best";
    const { id, progress } = await startDownload({ url: body.url.trim(), format });

    return Response.json({ id, progress }, { status: 202 });
  } catch (error) {
    return Response.json(
      { error: "Failed to start download", details: String(error) },
      { status: 500 }
    );
  }
}

export async function GET(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  
  if (id) {
    const progress = getDownloadProgress(id);
    if (!progress) {
      return Response.json({ error: "Download not found" }, { status: 404 });
    }
    return Response.json({ progress });
  }

  const downloads = getActiveDownloads();
  return Response.json({ downloads });
}

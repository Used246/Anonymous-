import { NextRequest } from "next/server";
import { getVideoInfo } from "@/lib/downloader";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const url = req.nextUrl.searchParams.get("url");

  if (!url || url.trim().length === 0) {
    return Response.json({ error: "URL parameter is required" }, { status: 400 });
  }

  try {
    const info = await getVideoInfo(url.trim());
    if (!info) {
      return Response.json({ error: "Could not fetch video info" }, { status: 404 });
    }
    return Response.json({ info });
  } catch (error) {
    return Response.json(
      { error: "Failed to get video info", details: String(error) },
      { status: 500 }
    );
  }
}

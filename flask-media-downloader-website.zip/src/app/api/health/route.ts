import { execSync } from "child_process";

export const dynamic = "force-dynamic";

export async function GET() {
  const checks: Record<string, boolean | string> = {};

  // Check yt-dlp
  try {
    const version = execSync("yt-dlp --version", { encoding: "utf-8", timeout: 5000 }).trim();
    checks["yt-dlp"] = version;
  } catch {
    checks["yt-dlp"] = false;
  }

  // Check db
  try {
    const { db } = await import("@/db");
    const { sql } = await import("drizzle-orm");
    await db.execute(sql`select 1`);
    checks["database"] = true;
  } catch {
    checks["database"] = false;
  }

  const allOk = Object.values(checks).every((v) => v !== false);

  return Response.json({
    ok: allOk,
    service: "Anonymous Downloader",
    version: "2.0.0",
    checks,
  });
}

import { NextRequest } from "next/server";
import { searchVideos } from "@/lib/downloader";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const query = req.nextUrl.searchParams.get("q");
  const limit = parseInt(req.nextUrl.searchParams.get("limit") || "20");

  if (!query || query.trim().length === 0) {
    return Response.json({ error: "Query parameter 'q' is required" }, { status: 400 });
  }

  try {
    const results = await searchVideos(query.trim(), Math.min(limit, 50));
    return Response.json({ results, count: results.length });
  } catch (error) {
    return Response.json(
      { error: "Search failed", details: String(error) },
      { status: 500 }
    );
  }
}

import { getDownloadedFiles, deleteFile } from "@/lib/downloader";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const files = getDownloadedFiles();
    return Response.json({ files });
  } catch (error) {
    return Response.json(
      { error: "Failed to list downloads", details: String(error) },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  const filename = req.nextUrl.searchParams.get("file");
  if (!filename) {
    return Response.json({ error: "File parameter required" }, { status: 400 });
  }

  const success = deleteFile(filename);
  if (!success) {
    return Response.json({ error: "File not found" }, { status: 404 });
  }

  return Response.json({ success: true });
}

import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Anonymous — YouTube & Social Media Downloader",
  description: "Anonymous by Anonymous Tech Team 2026 — Download videos, extract MP3 at 192kbps, merge MP4s. Fast, free, anonymous.",
  keywords: ["youtube downloader", "mp3 converter", "video downloader", "anonymous", "social media downloader"],
  authors: [{ name: "Anonymous Tech Team 2026" }],
  openGraph: {
    title: "Anonymous — YouTube & Social Media Downloader",
    description: "Download from YouTube & social media. MP3 192kbps, MP4 merging. By Anonymous Tech Team 2026.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-anon-black text-anon-text antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
